//: C11:NoThread.cpp
#include "LiftOff.h"

int main() {
  LiftOff launch(10);
  launch.run();
} ///:~
