//: C0B:Dummy.cpp
// To give the makefile at least one target 
// for this directory
int main() {} ///:~
