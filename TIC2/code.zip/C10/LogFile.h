//: C10:LogFile.h
#ifndef LOGFILE_H
#define LOGFILE_H
#include <fstream>

std::ofstream& logfile();

#endif // LOGFILE_H ///:~
